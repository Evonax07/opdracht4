<?php

include '../db.php'; 

class tafel {
    private $dbh;

    public function __construct(restaurant $dbh) { 
        $this->dbh = $dbh;
    }

    public function inserttafel($Personnen, $tafelnummer) { 
        return $this->dbh->execute("INSERT INTO tafel (Personnen, tafelnummer) 
        VALUES (?,?)", [$Personnen, $tafelnummer]);
    }
}
?>

<?php
include '../db.php'; 

class Klant {
    private $dbh;

    public function __construct(restaurant $dbh) { 
        $this->dbh = $dbh;
    }

    public function insertKlant($naam, $email, $password) { 
        return $this->dbh->execute("INSERT INTO tafel (naam, email, password) 
        VALUES (?,?,?)", [$naam, $email, $password]);
    }
}
?>
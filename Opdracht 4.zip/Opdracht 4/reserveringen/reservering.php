<?php

include '../db.php'; 

class reservering {
    private $dbh;

    public function __construct(restaurant $dbh) { 
        $this->dbh = $dbh;
    }

    public function insertreservering($naam, $achternaam, $datum) { 
        return $this->dbh->execute("INSERT INTO reservering (naam, achternaam, datum) 
        VALUES (?,?,?)", [$naam, $achternaam, $datum]);
    }
}
?>